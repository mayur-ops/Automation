package com.automation.practice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class zoro {
    public static WebDriver driver;

    @Before
    public void setUp(){
        WebDriverManager.chromedriver().setup();
        driver= new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        driver.get("https://www.zoro.co.uk/");
        driver.manage().window().maximize();
    }
    @Test
    public void signIn(){
       WebElement signInButton = driver.findElement(By.id("HeaderMenu.showLoginDialogButton"));
       signInButton.click();
       WebElement createAccount = driver.findElement(By.xpath("//button[contains(text(),'Create account')]"));
       createAccount.click();
       WebElement registerEmail = driver.findElement(By.xpath("//input[@id='register_email']"));
       registerEmail.sendKeys("mkp802002@gmail.com");
       WebElement password = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/div/div[2]/div/form/div/div[2]/div/div[1]/input"));
       password.sendKeys("shreeram");
       WebElement confirmPassword = driver.findElement(By.xpath("//input[@id='confirmPassword']"));
       driver.findElement(By.xpath("//button[contains(text(),'Continue')]")).click();

       // i need to complete from this end

       //WebElement title = driver.findElement(By.xpath("//body/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/select[1]"));
       //title.s
       //WebElement firstName = driver.findElement(By.xpath("//input[@id='firstName']"));
       //firstName.sendKeys("Mayurkumar");

    }
    @After
    public void tearDown(){
        driver.quit();
    }
}
